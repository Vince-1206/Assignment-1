"""
Name:
Date started:
GitHub URL:
"""


def main():
    """..."""
    print("Song List 1.0 - by Your Name")


if __name__ == '__main__':
    main()
